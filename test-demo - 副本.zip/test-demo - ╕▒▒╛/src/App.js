import './App.css';
import {Navigate,Routes,Route} from 'react-router-dom'
import Login from './pages/Login';
import Home from './pages/Home';
import Show from './pages/Home/Show'
import Table from "./pages/Home/Table/table";
import RolesList from "./pages/RolesList";
import Category from "./pages/Category"
import GoodsList from "./pages/GoodsList";


function App() {
  return (
    <div className="App">
      <Routes>
        <Route path='/' element={<Login/>}> </Route>
        <Route path='/login' element={<Login/>}/>
        <Route path='/home' element={<Home/>}> 
          {/* 配置index,自动触发二级路由 */}
          <Route index element={<Show/>}/>
          <Route path='/home/show'  element={<Show/>}/>
          <Route path='/home/users' element={<Table/>}/>
          <Route path='/home/roles' element={<RolesList/>}/>
          <Route path='/home/category' element={<Category/>}/>
          <Route path='/home/goods' element={<GoodsList/>}/>
        </Route> 

        <Route path='*' element={<Navigate to='login'/>}> </Route>
      </Routes>
    </div>
  );
}

export default App;
