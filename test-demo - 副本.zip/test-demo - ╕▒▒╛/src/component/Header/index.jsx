import React, { Component } from 'react'
import  {SearchOutlined,QuestionCircleOutlined,BellOutlined,UserOutlined,FormOutlined} from '@ant-design/icons'
import './index.css'
import logo from '../../img/2.png'
import { Input } from 'antd';



export default class index extends Component {
  render() {
    return (
      <div className='header'>
        <div className='left-header'>
            <a >
                <img className='icon' src={logo}  />
                <h1>Ant Design Pro</h1>
            </a>
        </div> 

        <div className='right-header'>
            <div className='search-items'>
                <SearchOutlined style={{marginTop:'10px'}}/>
                <span>
                    <Input placeholder="周杰伦新专辑" />
                </span>
                
            </div>

            {/* 右侧其他框 */}
            <div className='space-item'>
                <QuestionCircleOutlined  style={{marginRight:'10px'}}/>
                <BellOutlined  style={{marginRight:'10px'}}/>
                <UserOutlined style={{marginRight:'10px'}}/>
                <FormOutlined  />
            </div>            
        </div>
      </div>
    )
  }
}
