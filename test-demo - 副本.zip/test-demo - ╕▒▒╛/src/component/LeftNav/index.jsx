import { LaptopOutlined, NotificationOutlined,HomeOutlined, UserOutlined } from '@ant-design/icons';
import { Layout, Menu } from 'antd';
import React from 'react';
import {NavLink} from 'react-router-dom'


const {Sider } = Layout;
function LeftNav() {

    return(
        <Sider width={200} className="site-layout-background">
        <Menu
            mode="inline"
            defaultSelectedKeys={['show']}
            defaultOpenKeys={['1']}
            style={{
            borderRight: 0,
            height: '100%',
            }}
            items={[
                {
                    key:'show',
                    icon:<HomeOutlined/>,
                    label:<NavLink to="/home/show">首页</NavLink>
                },
                {
                    key:'users',
                    icon:<UserOutlined/>,
                    label:<NavLink to="/home/users">用户管理</NavLink>
                },
                {
                    key:'category',
                    icon:<LaptopOutlined/>,
                    label:`电商管理`,
                    children:[{id:'/home/category',name:'品类管理'},{id:'/home/goods',name:'商品管理'}].map((event,j)=>{
                        return{
                            key1: j,
                            label:<NavLink to={event.id}>{event.name}</NavLink>,
                        }
                    })
                    /* children:new Array(2).fill(null).map((_,j)=>{
                        const subKey = j;
                        const rooter = ['category','goods'];
                        const title =['品类管理','商品管理'];
                        return{
                            key1: subKey,
                            label:<NavLink to={`/home/${rooter[j]}`}>{title[j]}</NavLink>,
                        }
                    }) */
                },
                {
                    key:'4',
                    icon:<NotificationOutlined/>,
                    label:<NavLink to="/home/roles">综合管理</NavLink>
                },
                
            ]}
        />
        </Sider>
    )   
} 

export default LeftNav;