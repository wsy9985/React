// import '../../App.css';
import { Button, Checkbox, Form, Input,message } from 'antd';
import axios from 'axios';
import {useNavigate} from 'react-router-dom'

function Login() {
    const navigate = useNavigate(); // 调用useNavigate方法实现路由跳转
    const onFinish = (values) => {
        console.log('Success:', values);
        axios.post('https://lianghj.top:8888/api/private/v1/login',{
        password:values.password,
        username:values.username
        })
        // 获取成功结果
        .then(res=>{
        let{meta,data} = res.data;
        if(meta.status === 200){
            message.success(meta.msg);
            sessionStorage.token = data.token; // 避免多个用户同时登录产生数据覆盖等问题
            navigate('/home'); //跳转到home
        }else{
            message.error('密码错误')
        }
        })
    };

    const onFinishFailed = (errorInfo) => {
        console.log('Failed:', errorInfo);
        message.error('请输入正确的用户名和密码');
    };
    return (
        <div className="Login">
        <Form
            name="basic"
            labelCol={{
            span: 8,
            }}
            wrapperCol={{
            span: 16,
            }}
            initialValues={{
            remember: true,
            }}
            onFinish={onFinish}
            onFinishFailed={onFinishFailed}
            autoComplete="off"
        >
            <Form.Item
            label="用户名"
            name="username"
            rules={[
                {
                required: true,
                message: 'Please input your username!',
                },
            ]}
            >
            <Input />
            </Form.Item>

            <Form.Item
            label="密&nbsp;&nbsp;&nbsp;码"
            name="password"
            rules={[
                {
                required: true,
                message: 'Please input your password!',
                },
            ]}
            >
            <Input.Password />
            </Form.Item>

            <Form.Item
            name="remember"
            valuePropName="checked"
            wrapperCol={{
                offset: 8,
                span: 16,
            }}
            >
            <Checkbox>记住账号</Checkbox>
            </Form.Item>

            <Form.Item
            wrapperCol={{
                offset: 8,
                span: 16,
            }}
            >
            <Button type="primary" htmlType="submit">
                登录
            </Button>
            </Form.Item>
        </Form>
        </div>
  );
}

export default Login;
