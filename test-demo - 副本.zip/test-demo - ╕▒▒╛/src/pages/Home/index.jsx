import { Breadcrumb, Layout} from 'antd';
import React from 'react';
import {Outlet} from 'react-router-dom'
import LeftNav from '../../component/LeftNav';
import Header from '../../component/Header'


const { Content,Footer} = Layout;
/* const items1 = ['1', '2', '3'].map((key) => ({
  key,
  label: `nav ${key}`,
})); */

const Home = () => (
  <Layout style={{height:"100vh"}}>
    <Header>
      
    </Header>
    <Layout>
      <LeftNav></LeftNav>
      <Layout
        style={{
          padding: '0 24px 24px',
        }}
      >
        <Breadcrumb
          style={{
            margin: '16px 0',
          }}
        >
          <Breadcrumb.Item>Home</Breadcrumb.Item>
          <Breadcrumb.Item>List</Breadcrumb.Item>
          <Breadcrumb.Item>App</Breadcrumb.Item>
        </Breadcrumb>
        <Content
          className="site-layout-background"
          style={{
            padding:24,
            margin:0,
            minHeight:280,
          }}
        >
          {/* <Table></Table> */}
          {/* Outlet */}
          <Outlet></Outlet>
        </Content>
        <Footer style={{ textAlign: 'center' }}>
          使用Chrome@2022浏览器获得更佳体验效果
        </Footer>
      </Layout>
    </Layout>
  </Layout>
);

export default Home;
