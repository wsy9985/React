function GoodsList() {
  return (
    <div>
        <h1>Welcom To E-commerce Management(Goods)</h1>
        <h2>(Making)</h2>
    </div>
  );
}
export default GoodsList;
