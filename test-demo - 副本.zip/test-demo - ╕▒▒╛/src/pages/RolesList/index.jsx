// import './App.css';
import './index.css'

function RolesList() {
  return (
    <div className="manage">
        <h1>Welcom To Comprehensive Management</h1>
        <h2>(Making)</h2>
    </div>
  );
}

export default RolesList;
