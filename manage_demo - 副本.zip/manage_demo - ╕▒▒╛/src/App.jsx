import React from 'react'
import { Button,Layout } from 'antd';
import { Outlet } from 'react-router-dom'
import Header from '../src/components/Header'
const { Sider, Content } = Layout;
export default function App() {
  return (
    <div>
      <Layout className='app_lay'>
        <Header></Header>
        <Layout>
          <Sider theme="light">Sider</Sider>
          <Content>Content</Content>
        </Layout>
        <footer>Respect|Copyright &copy; 2022 Author siyuanWu </footer>
      </Layout>
      <Outlet />
    </div>
  )
}
