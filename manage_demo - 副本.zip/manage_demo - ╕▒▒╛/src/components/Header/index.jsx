import React, {useState, Component, useEffect } from 'react'
import  {SearchOutlined, DownOutlined, SmileOutlined,QuestionCircleOutlined,BellOutlined,UserOutlined,FormOutlined} from '@ant-design/icons'
import { Dropdown, Menu, Space ,Input} from 'antd';
import './index.css'
import defaultAvatar from '../../img/4.webp'
import logo from '../../img/2.png'




export default function() {
  const [avatar,setAvatar] = useState(defaultAvatar);
  const [username,setUsername] = useState('游客');

  useEffect(()=>{
    let username1 = localStorage.getItem('username')
    if(username1){
      setUsername(username1);
    }
  })

  const items = [
    {key: '1',label: (<span style={{textAlign:'center',display:'block'}}>修改资料</span>),},
    {key: '2',label: (<hr style={{color:'white',fontSize:'10px',margin:'0 ', padding:'0',width:'100%'}}/>),},
    {key: '3',label: (<span style={{textAlign:'center',display:'block'}}>退出登录</span>),},
  ]

  const menu = (
    <Menu items={items}>   
    </Menu>
  );

  
  return (
    <div className='header'>
      <div className='left-header'>
          <a >
              <img className='icon' src={logo}  />
              <h1>Ant Design Pro</h1>
          </a>
      </div> 

      <div className='right-header'>
          <div className='search-items'>
              <SearchOutlined style={{marginTop:'10px'}}/>
              <span>
                  <Input placeholder="周杰伦新专辑" />
              </span>
              
          </div>

          {/* 右侧其他框 */}
          <div className='space-item'>
            <Dropdown overlay={menu}>
            <a className='ant-dropdown-link'  onClick={e => e.preventDefault()}>
              <Space>
                <img src={avatar} className="right_avator" />
                <span>{username}</span>
              <DownOutlined />
              </Space>
              </a>
            </Dropdown>
          </div>            
      </div>
    </div>
  )
}
