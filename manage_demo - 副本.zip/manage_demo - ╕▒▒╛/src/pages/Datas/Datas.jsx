import React from 'react'

export default function Datas() {
  return (
    <div>Datas12222</div>
  )
}
